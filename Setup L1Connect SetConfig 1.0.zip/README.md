# Setup-L1Connect-SetConfig
Sample OrchestrationScript for CloudShell

## How to package
C:\[YourDirectory]>zip -r "Setup L1Connect SetConfig 1.0.zip" ./  
or  
C:\[YourDirectory]>7z.exe a "Setup L1Connect SetConfig 1.0.zip" ./  

